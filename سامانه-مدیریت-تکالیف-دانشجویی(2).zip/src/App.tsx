import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  GraduationCap, 
  Send, 
  ClipboardList, 
  Star, 
  MessageSquare, 
  BarChart3, 
  LogOut,
  ChevronDown,
  ChevronUp,
  CheckCircle2
} from 'lucide-react';

type Assignment = {
  id: number;
  student_id: string;
  week: number;
  title: string;
  content: string;
  created_at: string;
  score: number | null;
  feedback: string | null;
  graded_at: string | null;
};

type Stat = {
  student_id: string;
  average_score: number;
  graded_count: number;
};

export default function App() {
  const [userId, setUserId] = useState<string>('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [stats, setStats] = useState<Stat[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newWeek, setNewWeek] = useState<number>(1);
  const [gradingId, setGradingId] = useState<number | null>(null);
  const [gradeScore, setGradeScore] = useState<number>(0);
  const [gradeFeedback, setGradeFeedback] = useState('');

  const isTeacher = userId === '100';

  const fetchData = async () => {
    try {
      const [assignmentsRes, statsRes] = await Promise.all([
        fetch('/api/assignments'),
        fetch('/api/stats')
      ]);
      const assignmentsData = await assignmentsRes.json();
      const statsData = await statsRes.json();
      setAssignments(assignmentsData);
      setStats(statsData);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
    if (isLoggedIn) {
      fetchData();
    }
  }, [isLoggedIn]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (userId.trim()) {
      setIsLoggedIn(true);
    }
  };

  const handleSubmitAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/assignments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: userId,
          week: newWeek,
          title: newTitle,
          content: newContent
        })
      });
      const data = await res.json();
      if (res.ok) {
        setNewTitle('');
        setNewContent('');
        fetchData();
      } else {
        setError(data.error || 'خطایی رخ داد');
      }
    } catch (error) {
      console.error('Error submitting assignment:', error);
      setError('خطا در برقراری ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  const handleGrade = async (assignmentId: number) => {
    setLoading(true);
    try {
      const res = await fetch('/api/grade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          teacherId: userId,
          assignmentId,
          score: gradeScore,
          feedback: gradeFeedback
        })
      });
      if (res.ok) {
        setGradingId(null);
        setGradeScore(0);
        setGradeFeedback('');
        fetchData();
      }
    } catch (error) {
      console.error('Error grading:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-4 font-sans" dir="rtl">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md border border-black/5"
        >
          <div className="flex justify-center mb-6">
            <div className="bg-emerald-100 p-4 rounded-full">
              <GraduationCap className="w-12 h-12 text-emerald-600" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-center mb-2 text-stone-800">خوش آمدید</h1>
          <p className="text-stone-500 text-center mb-8">لطفاً کد کاربری خود را وارد کنید</p>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-stone-700 mb-1 mr-1">کد کاربری</label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 w-5 h-5" />
                <input 
                  type="text" 
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="w-full pr-10 pl-4 py-3 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                  placeholder="کد خود را وارد کنید"
                  required
                />
              </div>
            </div>
            <button 
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl transition-colors shadow-lg shadow-emerald-200"
            >
              ورود به سامانه
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] font-sans pb-12" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 p-2 rounded-lg">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-stone-800 hidden sm:block">سامانه مدیریت تکالیف</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end">
              <span className="text-xs text-stone-500">کاربر فعلی:</span>
              <span className="text-sm font-bold text-stone-800">{isTeacher ? 'استاد (۱۰۰)' : `دانشجو (${userId})`}</span>
            </div>
            <button 
              onClick={() => setIsLoggedIn(false)}
              className="p-2 hover:bg-stone-100 rounded-full text-stone-500 transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Sidebar / Stats */}
        <div className="lg:col-span-1 space-y-6">
          <section className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200">
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 className="w-5 h-5 text-emerald-600" />
              <h2 className="font-bold text-stone-800">میانگین نمرات</h2>
            </div>
            <div className="space-y-3">
              {stats.length === 0 ? (
                <p className="text-sm text-stone-400 text-center py-4">هنوز نمره‌ای ثبت نشده است</p>
              ) : (
                stats.map((stat) => (
                  <div key={stat.student_id} className="flex items-center justify-between p-3 bg-stone-50 rounded-xl">
                    <span className="text-sm font-medium text-stone-600">کد: {stat.student_id}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-stone-400">({stat.graded_count} تکلیف)</span>
                      <span className="font-bold text-emerald-600">{stat.average_score.toFixed(1)}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>

          {!isTeacher && (
            <section className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200">
              <div className="flex items-center gap-2 mb-4">
                <Send className="w-5 h-5 text-emerald-600" />
                <h2 className="font-bold text-stone-800">ثبت تکلیف جدید</h2>
              </div>
              <form onSubmit={handleSubmitAssignment} className="space-y-4">
                {error && (
                  <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs font-bold">
                    {error}
                  </div>
                )}
                <div>
                  <label className="block text-xs font-bold text-stone-500 mb-1 mr-1">انتخاب هفته:</label>
                  <select 
                    value={newWeek}
                    onChange={(e) => setNewWeek(Number(e.target.value))}
                    className="w-full px-4 py-2 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(w => (
                      <option key={w} value={w}>هفته {w}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <input 
                    type="text" 
                    placeholder="عنوان تکلیف"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <textarea 
                    placeholder="متن تکلیف یا لینک فایل..."
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl border border-stone-200 focus:ring-2 focus:ring-emerald-500 outline-none h-32 resize-none"
                    required
                  />
                </div>
                <button 
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl transition-all disabled:opacity-50"
                >
                  {loading ? 'در حال ارسال...' : 'ارسال تکلیف'}
                </button>
              </form>
            </section>
          )}
        </div>

        {/* Main Feed */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ClipboardList className="w-6 h-6 text-emerald-600" />
              <h2 className="text-xl font-bold text-stone-800">لیست تکالیف</h2>
            </div>
            <button 
              onClick={fetchData}
              className="text-sm text-emerald-600 hover:underline"
            >
              بروزرسانی لیست
            </button>
          </div>

          <div className="space-y-4">
            {assignments.length === 0 ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-stone-300">
                <p className="text-stone-400">هنوز هیچ تکلیفی ثبت نشده است</p>
              </div>
            ) : (
              assignments.map((assignment) => (
                <motion.div 
                  layout
                  key={assignment.id}
                  className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 overflow-hidden"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="bg-stone-100 text-stone-600 text-[10px] font-bold px-2 py-0.5 rounded-full border border-stone-200">هفته {assignment.week}</span>
                        <h3 className="font-bold text-lg text-stone-800">{assignment.title}</h3>
                      </div>
                      <p className="text-xs text-stone-400">
                        توسط: {assignment.student_id} • {new Date(assignment.created_at).toLocaleString('fa-IR')}
                      </p>
                    </div>
                    {assignment.score !== null ? (
                      <div className="bg-emerald-50 px-3 py-1 rounded-full flex items-center gap-1 border border-emerald-100">
                        <Star className="w-4 h-4 text-emerald-600 fill-emerald-600" />
                        <span className="text-sm font-bold text-emerald-700">نمره: {assignment.score}</span>
                      </div>
                    ) : (
                      <div className="bg-amber-50 px-3 py-1 rounded-full border border-amber-100">
                        <span className="text-xs font-medium text-amber-600">در انتظار نمره</span>
                      </div>
                    )}
                  </div>

                  <div className="bg-stone-50 p-4 rounded-2xl text-stone-700 text-sm whitespace-pre-wrap mb-4">
                    {assignment.content}
                  </div>

                  {assignment.feedback && (
                    <div className="flex items-start gap-3 bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100/50 mb-4">
                      <MessageSquare className="w-5 h-5 text-emerald-600 shrink-0 mt-1" />
                      <div>
                        <p className="text-xs font-bold text-emerald-700 mb-1">بازخورد استاد:</p>
                        <p className="text-sm text-stone-600 italic">{assignment.feedback}</p>
                      </div>
                    </div>
                  )}

                  {isTeacher && (
                    <div className="mt-4 pt-4 border-t border-stone-100">
                      {gradingId === assignment.id ? (
                        <div className="space-y-4 bg-stone-50 p-4 rounded-2xl">
                          <div className="flex items-center gap-4">
                            <label className="text-sm font-medium text-stone-600">نمره (۰ تا ۲۰):</label>
                            <input 
                              type="number" 
                              min="0" 
                              max="20"
                              value={gradeScore}
                              onChange={(e) => setGradeScore(Number(e.target.value))}
                              className="w-20 px-3 py-1 rounded-lg border border-stone-200 outline-none focus:ring-2 focus:ring-emerald-500"
                            />
                          </div>
                          <div>
                            <textarea 
                              placeholder="بازخورد کیفی و نظرات..."
                              value={gradeFeedback}
                              onChange={(e) => setGradeFeedback(e.target.value)}
                              className="w-full px-4 py-2 rounded-xl border border-stone-200 outline-none focus:ring-2 focus:ring-emerald-500 h-20 resize-none text-sm"
                            />
                          </div>
                          <div className="flex gap-2">
                            <button 
                              onClick={() => handleGrade(assignment.id)}
                              disabled={loading}
                              className="flex-1 bg-emerald-600 text-white py-2 rounded-xl font-bold text-sm hover:bg-emerald-700 transition-colors disabled:opacity-50"
                            >
                              ثبت نمره
                            </button>
                            <button 
                              onClick={() => setGradingId(null)}
                              className="px-4 py-2 bg-stone-200 text-stone-600 rounded-xl font-bold text-sm hover:bg-stone-300 transition-colors"
                            >
                              انصراف
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button 
                          onClick={() => {
                            setGradingId(assignment.id);
                            setGradeScore(assignment.score || 0);
                            setGradeFeedback(assignment.feedback || '');
                          }}
                          className="w-full py-2 border-2 border-dashed border-emerald-200 text-emerald-600 rounded-xl text-sm font-bold hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2"
                        >
                          {assignment.score !== null ? 'ویرایش نمره و بازخورد' : 'ثبت نمره و بازخورد'}
                        </button>
                      )}
                    </div>
                  )}
                </motion.div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

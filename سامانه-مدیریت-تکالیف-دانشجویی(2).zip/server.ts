import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("assignments.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS assignments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id TEXT NOT NULL,
    week INTEGER NOT NULL DEFAULT 1,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS grades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    assignment_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    feedback TEXT,
    graded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assignment_id) REFERENCES assignments(id)
  );
`);

// Migration: Add week column if it doesn't exist (for existing databases)
try {
  db.prepare("ALTER TABLE assignments ADD COLUMN week INTEGER NOT NULL DEFAULT 1").run();
} catch (e) {
  // Column already exists or table doesn't exist yet
}

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // API Routes
  
  // Submit assignment
  app.post("/api/assignments", (req, res) => {
    const { studentId, week, title, content } = req.body;
    if (!studentId || !week || !title || !content) {
      return res.status(400).json({ error: "تمام فیلدها الزامی هستند" });
    }
    
    const weekNum = parseInt(week);
    if (isNaN(weekNum) || weekNum < 1 || weekNum > 8) {
      return res.status(400).json({ error: "هفته نامعتبر است (باید بین ۱ تا ۸ باشد)" });
    }

    // Check if student already submitted for this week
    const existing = db.prepare("SELECT id FROM assignments WHERE student_id = ? AND week = ?").get(studentId, weekNum);
    if (existing) {
      return res.status(400).json({ error: `شما قبلاً برای هفته ${weekNum} تکلیف ثبت کرده‌اید` });
    }

    const stmt = db.prepare("INSERT INTO assignments (student_id, week, title, content) VALUES (?, ?, ?, ?)");
    const info = stmt.run(studentId, weekNum, title, content);
    res.json({ id: info.lastInsertRowid });
  });

  // Get all assignments with grades
  app.get("/api/assignments", (req, res) => {
    const assignments = db.prepare(`
      SELECT a.*, g.score, g.feedback, g.graded_at 
      FROM assignments a 
      LEFT JOIN grades g ON a.id = g.assignment_id
      ORDER BY a.created_at DESC
    `).all();
    res.json(assignments);
  });

  // Grade an assignment
  app.post("/api/grade", (req, res) => {
    const { teacherId, assignmentId, score, feedback } = req.body;
    if (teacherId !== "100") {
      return res.status(403).json({ error: "دسترسی غیرمجاز" });
    }
    
    // Check if already graded
    const existing = db.prepare("SELECT id FROM grades WHERE assignment_id = ?").get(assignmentId);
    
    if (existing) {
      const stmt = db.prepare("UPDATE grades SET score = ?, feedback = ? WHERE assignment_id = ?");
      stmt.run(score, feedback, assignmentId);
    } else {
      const stmt = db.prepare("INSERT INTO grades (assignment_id, score, feedback) VALUES (?, ?, ?)");
      stmt.run(assignmentId, score, feedback);
    }
    
    res.json({ success: true });
  });

  // Get stats (average grades per student)
  app.get("/api/stats", (req, res) => {
    const stats = db.prepare(`
      SELECT student_id, AVG(score) as average_score, COUNT(score) as graded_count
      FROM assignments a
      JOIN grades g ON a.id = g.assignment_id
      GROUP BY student_id
    `).all();
    res.json(stats);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
